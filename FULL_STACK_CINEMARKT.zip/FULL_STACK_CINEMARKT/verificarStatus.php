<?php
session_start();
header('Content-Type: application/json');

$response = [
    'logado' => isset($_SESSION['usuario_id']),
    'nome' => isset($_SESSION['usuario_nome']) ? $_SESSION['usuario_nome'] : '',
    'id' => isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : 0
];

echo json_encode($response);
?>