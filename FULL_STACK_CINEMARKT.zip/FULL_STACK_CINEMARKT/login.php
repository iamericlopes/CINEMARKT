<?php
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $senha = trim($_POST['senha']); // Alterado de 'password' para 'senha' para corresponder ao formulário

    if (empty($email) || empty($senha)) {
        echo '<script>alert("E-mail e senha são obrigatórios."); window.location.href = "login.html";</script>';
        exit;
    }

    $stmt = $connect->prepare('SELECT id, nome, senha FROM tb_login WHERE email = ?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows == 0) {
        echo '<script>alert("Usuário ou senha incorretos."); window.location.href = "login.html";</script>';
        exit;
    }

    $usuario = $resultado->fetch_assoc();

    if (password_verify($senha, $usuario['senha'])) {
        // Inicia a sessão para manter o usuário logado
        session_start();
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['usuario_nome'] = $usuario['nome'];
        $_SESSION['usuario_email'] = $email;
        
        echo '<script>alert("Login efetuado com sucesso!"); window.location.href = "index.html";</script>';
    } else {
        echo '<script>alert("Usuário ou senha incorretos."); window.location.href = "login.html";</script>';
    }
}
?>