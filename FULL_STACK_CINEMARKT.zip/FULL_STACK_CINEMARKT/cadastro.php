<?php
include "connect.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    // Usar o mesmo nome do campo que está no formulário HTML
    $senha = trim($_POST['password']);
    $confirmaSenha = trim($_POST['confirmaSenha']);

    // Validar campos vazios
    if (empty($nome) || empty($email) || empty($senha) || empty($confirmaSenha)) {
        echo '<script>alert("Todos os campos são obrigatórios."); window.location.href = "cadastro.html";</script>';
        exit;
    }

    // Validar e-mail
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo '<script>alert("E-mail inválido."); window.location.href = "cadastro.html";</script>';
        exit;
    }

    // Verificar se o e-mail já existe
    $stmt = $connect->prepare('SELECT id FROM tb_login WHERE email = ?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        echo '<script>alert("E-mail já cadastrado."); window.location.href = "cadastro.html";</script>';
        exit;
    }

    // Validar senha e confirmação
    if ($senha !== $confirmaSenha) {
        echo '<script>alert("As senhas não coincidem."); window.location.href = "cadastro.html";</script>';
        exit;
    }

    // Simplificando a validação de senha para testes iniciais
    if (strlen($senha) < 8) {
        echo '<script>alert("A senha deve ter pelo menos 8 caracteres."); window.location.href = "cadastro.html";</script>';
        exit;
    }

    // Hash da senha
    $senhaHash = password_hash($senha, PASSWORD_BCRYPT);

    // Inserir no banco de dados
    $stmt = $connect->prepare('INSERT INTO tb_login (nome, email, senha) VALUES (?, ?, ?)');
    $stmt->bind_param('sss', $nome, $email, $senhaHash);

    if ($stmt->execute()) {
        echo '<script>alert("Cadastro efetuado com sucesso!"); window.location.href = "loginFront.php";</script>';
    } else {
        echo '<script>alert("Erro ao cadastrar: ' . $stmt->error . '"); window.location.href = "cadastro.html";</script>';
    }
} else {
    // Se não for POST, redirecionar para o formulário
    header("Location: cadastro.html");
    exit;
}
?>