<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "db_cinema";

$connect = new mysqli($host, $user, $pass, $banco);

if ($connect->connect_error) {
    die("Erro na conexão: " . $connect->connect_error);
}
?>
