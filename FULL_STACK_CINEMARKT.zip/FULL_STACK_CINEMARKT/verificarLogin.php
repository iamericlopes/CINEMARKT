<?php
session_start();

function estaLogado() {
    return isset($_SESSION['usuario_id']);
}

function obterNomeUsuario() {
    return isset($_SESSION['usuario_nome']) ? $_SESSION['usuario_nome'] : '';
}

function obterEmailUsuario() {
    return isset($_SESSION['usuario_email']) ? $_SESSION['usuario_email'] : '';
}

function obterIdUsuario() {
    return isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : 0;
}
?>