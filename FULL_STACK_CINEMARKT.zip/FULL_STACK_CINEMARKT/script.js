document.addEventListener("DOMContentLoaded", function () {
  // Função para criar e gerenciar carrosséis
  const carouselSections = document.querySelectorAll("#filmes, #top-filmes");

  carouselSections.forEach(section => {
    const carousel = section.querySelector(".carousel-container");
    const items = carousel.querySelectorAll(".carousel-item");
    const prevButton = section.querySelector(".carousel-button.prev");
    const nextButton = section.querySelector(".carousel-button.next");
    const itemWidth = items[0].offsetWidth + 15; // 15px é o gap entre items
    const visibleItems = Math.floor(carousel.offsetWidth / itemWidth);

    // Configuração inicial
    let currentPosition = 0;
    const maxScroll = carousel.scrollWidth - carousel.clientWidth;

    function updateButtonStates() {
      prevButton.disabled = currentPosition <= 0;
      nextButton.disabled = currentPosition >= maxScroll;
      prevButton.style.opacity = prevButton.disabled ? "0.5" : "1";
      nextButton.style.opacity = nextButton.disabled ? "0.5" : "1";
    }

    // Função para scroll do carrossel
    function scrollCarousel(direction) {
      const scrollAmount = direction * itemWidth;
      
      if (direction > 0) {
        if (currentPosition >= maxScroll) {
          // Volta ao início se estiver no final
          currentPosition = 0;
        } else {
          currentPosition = Math.min(currentPosition + scrollAmount, maxScroll);
        }
      } else {
        if (currentPosition <= 0) {
          // Vai para o final se estiver no início
          currentPosition = maxScroll;
        } else {
          currentPosition = Math.max(currentPosition + scrollAmount, 0);
        }
      }

      carousel.scrollTo({
        left: currentPosition,
        behavior: 'smooth'
      });

      updateButtonStates();
    }

    // Event Listeners para os botões
    prevButton.addEventListener("click", () => scrollCarousel(-1));
    nextButton.addEventListener("click", () => scrollCarousel(1));

    // Event Listener para clique nos filmes
    items.forEach(item => {
      item.addEventListener('click', () => {
        showMovieDetails(item);
      });
    });

    // Atualiza estados iniciais
    updateButtonStates();

  });

  
});



// Banco de dados de filmes ampliado
const movieDatabase = {
  "Sonic 3": {
    sinopse: "Em Sonic 3, Sonic, Tails e Knuckles enfrentam o Dr. Robotnik mais uma vez, agora com a ajuda do vilão Shadow the Hedgehog. Uma nova ameaça surge quando Shadow revela seus poderes incríveis e um plano para dominar o mundo.",
    trailer: "https://www.youtube.com/watch?v=sYCpSZnRVLM",
    posterUrl: "Imagens/MoviePoster-a9917f53-00fa-460a-b343-cec0b0de7649.webp",
    streaming: ["Prime Video", "Google Play"]
  },
  "Ainda Estou Aqui": {
    sinopse: "Baseado em uma história real, o filme acompanha a jornada de uma mulher em busca de respostas após o desaparecimento de seu marido em meio a um conflito político. Uma história de amor, perda e resiliência.",
    trailer: "https://www.youtube.com/watch?v=exemplo",
    posterUrl: "Imagens/MoviePoster-f636b229-8834-425f-b2a8-2a2f8bdfdb14.webp",
    streaming: ["Netflix", "Globoplay"]
  },
  "O Poderoso Chefão": {
    sinopse: "Don Vito Corleone é o chefe de uma família mafiosa na Nova York dos anos 1940. Quando se recusa a entrar no comércio de drogas, um conflito entre as famílias mafiosas se inicia, resultando em assassinato e traição.",
    trailer: "https://www.youtube.com/watch?v=sY1S34973zA",
    posterUrl: "https://br.web.img3.acsta.net/medias/nmedia/18/90/93/20/20120876.jpg",
    streaming: ["Netflix", "Prime Video", "Apple TV"]
  },
  "Jurassic Park": {
    sinopse: "O paleontólogo Dr. Alan Grant e a paleobotânica Dra. Ellie Sattler são convidados para visitar um parque temático com dinossauros recriados geneticamente. O que deveria ser um passeio extraordinário se torna um pesadelo quando os dinossauros escapam de suas jaulas.",
    trailer: "https://www.youtube.com/watch?v=QWBKEmWWL38",
    posterUrl: "https://m.media-amazon.com/images/I/91PPR5VVHeL._AC_UF894,1000_QL80_.jpg",
    streaming: ["Netflix", "Apple TV"]
  },
  "Matrix": {
    sinopse: "Um programador de computadores descobre que o mundo em que vive é uma simulação criada por máquinas que escravizaram a humanidade. Junto com um grupo de rebeldes, ele luta para libertar as mentes das pessoas do controle das máquinas.",
    trailer: "https://www.youtube.com/watch?v=2KnZac176Hs",
    posterUrl: "https://br.web.img2.acsta.net/medias/nmedia/18/91/08/82/20128877.JPG",
    streaming: ["HBO Max", "Prime Video"]
  },
  "Interestelar": {
    sinopse: "Em um futuro onde a Terra está se tornando inabitável, um grupo de astronautas viaja através de um buraco de minhoca em busca de um novo lar para a humanidade, enfrentando as leis relativísticas do tempo e espaço.",
    trailer: "https://www.youtube.com/watch?v=zSWdZVtXT7E",
    posterUrl: "https://upload.wikimedia.org/wikipedia/pt/3/3a/Interstellar_Filme.png",
    streaming: ["Prime Video", "Apple TV", "Google Play"]
  },
  "A Origem": {
    sinopse: "Dom Cobb é um ladrão especializado no roubo de segredos do subconsciente durante o estado de sono. Sua habilidade o torna alvo de poderosos inimigos e o afasta de sua família, mas ele recebe uma chance de redenção com um último trabalho: plantar uma ideia na mente de alguém.",
    trailer: "https://www.youtube.com/watch?v=YoHD9XEInc0",
    posterUrl: "https://upload.wikimedia.org/wikipedia/pt/8/84/AOrigemPoster.jpg",
    streaming: ["Netflix", "HBO Max"]
  },
  "Gladiador": {
    sinopse: "Maximus, um general romano respeitado, é traído quando o ambicioso filho do imperador, Commodus, assassina seu pai e toma o trono. Reduzido à escravidão, Maximus ressurge como gladiador e planeja sua vingança contra o imperador.",
    trailer: "https://www.youtube.com/watch?v=owK1qxDselE",
    posterUrl: "https://upload.wikimedia.org/wikipedia/pt/thumb/4/44/GladiadorPoster.jpg/230px-GladiadorPoster.jpg",
    streaming: ["Star+", "Prime Video"]
  },
  "Pantera Negra": {
    sinopse: "Após a morte de seu pai, T'Challa retorna a Wakanda para tomar seu lugar como rei. No entanto, quando um poderoso inimigo reaparece, o poder de T'Challa como rei e Pantera Negra é testado quando ele é atraído para um conflito que coloca o destino de Wakanda e do mundo em risco.",
    trailer: "https://www.youtube.com/watch?v=xjDjIWPwcPU",
    posterUrl: "https://lumiere-a.akamaihd.net/v1/images/unnamed_13_75a3ebb1.jpeg?region=0%2C0%2C356%2C512",
    streaming: ["Disney+"]
  },
  "Mad Max: Estrada da Fúria": {
    sinopse: "Em um mundo apocalíptico, Max Rockatansky se une a Imperatriz Furiosa para fugir de um senhor da guerra e seu exército em uma armada de guerra motorizada. Juntos, eles lutam por sobrevivência enquanto buscam um lar melhor.",
    trailer: "https://www.youtube.com/watch?v=hEJnMQG9ev8",
    posterUrl: "https://upload.wikimedia.org/wikipedia/pt/thumb/2/23/Max_Mad_Fury_Road_Newest_Poster.jpg/250px-Max_Mad_Fury_Road_Newest_Poster.jpg",
    streaming: ["HBO Max", "Prime Video"]
  },
  "Coringa": {
    sinopse: "Arthur Fleck, um comediante fracassado que sofre de problemas mentais, é ignorado pela sociedade em Gotham City. Ele começa uma revolução violenta depois de ser espancado por jovens na rua, iniciando sua descida à loucura e sua transformação no infame vilão Coringa.",
    trailer: "https://www.youtube.com/watch?v=zAGVQLHvwOY",
    posterUrl: "https://upload.wikimedia.org/wikipedia/pt/thumb/6/63/Joker_%282019%29.jpg/250px-Joker_%282019%29.jpg",
    streaming: ["HBO Max", "Prime Video", "Apple TV"]
  },
  "Seven: Os Sete Crimes Capitais": {
    sinopse: "Dois detetives, um veterano prestes a se aposentar e um novato, caçam um serial killer que usa os sete pecados capitais como motivos para seus assassinatos. À medida que a investigação avança, eles se veem cada vez mais envolvidos no jogo doentio do assassino.",
    trailer: "https://www.youtube.com/watch?v=znmZoVkCjpI",
    posterUrl: "Imagens/MoviePoster-5d36ba40-405d-461d-bd03-90113657fcfb.webp",
    streaming: ["Netflix", "Prime Video"]
  },
  "O Rei Leão": {
    sinopse: "Simba, um jovem leão, é exilado de seu reino após ser acusado pela morte de seu pai, o Rei Mufasa. Com a ajuda de novos amigos, Simba terá que crescer e voltar para recuperar seu trono das garras de seu tio Scar.",
    trailer: "https://www.youtube.com/watch?v=7TavVZMewpY",
    posterUrl: "https://lumiere-a.akamaihd.net/v1/images/lion_king_the_2019_la_ih_ptb_1000_x_1440_2baad78d.jpeg?region=0%2C0%2C1000%2C1440",
    streaming: ["Disney+"]
  },
  "Capitão América: Admirável Mundo Novo": {
    sinopse: "Sam Wilson assume o manto de Capitão América e enfrenta novos desafios em um mundo pós-Blip. Enquanto lida com as expectativas de ser o símbolo da América, ele descobre uma conspiração que ameaça o equilíbrio global de poder.",
    trailer: "https://www.youtube.com/watch?v=exemplo",
    posterUrl: "Imagens/MoviePoster-21eb0c23-73f7-4717-b3ea-8cd74f022949.webp",
    streaming: ["Disney+"]
  },
  "Nosferatu": {
    sinopse: "Uma reinterpretação do clássico de terror, onde o Conde Orlok, um vampiro milenar, se apaixona por uma mulher e traz o terror para uma pacata cidade. Uma história sombria sobre obsessão e o preço da imortalidade.",
    trailer: "https://www.youtube.com/watch?v=exemplo",
    posterUrl: "Imagens/MoviePoster-d52fee4d-f8a2-4464-9e8e-a72ec3bb6efd.webp",
    streaming: ["HBO Max"]
  },
  "Vingadores: Ultimato": {
    sinopse: "Após os eventos devastadores de Vingadores: Guerra Infinita, o universo está em ruínas. Com a ajuda dos aliados restantes, os Vingadores se reúnem mais uma vez para reverter as ações de Thanos e restaurar o equilíbrio ao universo.",
    trailer: "https://www.youtube.com/watch?v=TcMBFSGVi1c",
    posterUrl: "https://br.web.img3.acsta.net/pictures/19/04/26/17/30/2428965.jpg",
    streaming: ["Disney+"]
  }
};

// Função para mostrar detalhes do filme
function showMovieDetails(item) {
  // Obter o título do filme
  const movieTitle = item.querySelector('h3').textContent;
  
  // Obter dados do filme do banco de dados
  const movieData = movieDatabase[movieTitle] || {
    sinopse: "Sinopse não disponível.",
    trailer: "#",
    posterUrl: item.querySelector('img').src,
    streaming: []
  };
  
  // Cria o modal
  const modal = document.createElement('div');
  modal.className = 'movie-modal';
  
  const modalContent = document.createElement('div');
  modalContent.className = 'modal-content';
  
  // Conteúdo do modal usando os dados do item do carrossel e do banco de dados
  modalContent.innerHTML = `
    <span class="close-modal">&times;</span>
    <div class="modal-poster">
      <a href="${movieData.trailer}" target="_blank" title="Assistir trailer">
        <img src="${movieData.posterUrl}" alt="${movieTitle}">
        <div class="play-overlay">
          <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 24 24" fill="white">
            <path d="M8 5v14l11-7z"/>
          </svg>
        </div>
      </a>
    </div>
    <div class="modal-info">
      <h3>${movieTitle}</h3>
      <p class="categoria">${item.querySelector('.categoria').textContent}</p>
      <p class="duracao">${item.querySelector('.duracao').textContent}</p>
      
      <div class="sinopse">
        <h4>Sinopse:</h4>
        <p>${movieData.sinopse}</p>
      </div>
      
      <div class="streaming">
        <h4>Onde Assistir:</h4>
      </div>
    </div>
  `;
  
  modal.appendChild(modalContent);
  document.body.appendChild(modal);
  
  // Fecha o modal ao clicar no X ou fora do conteúdo
  const closeBtn = modal.querySelector('.close-modal');
  closeBtn.onclick = () => modal.remove();
  
  modal.onclick = (e) => {
    if (e.target === modal) {
      modal.remove();
    }
  };
}