document.addEventListener("DOMContentLoaded", function() {
  // Verifica o status de login
  fetch('verificar_status.php')
    .then(response => response.json())
    .then(data => {
      const loginButton = document.querySelector('.login-button a');
      
      if (data.logado) {
        // Se estiver logado, muda o texto do botão e adiciona dropdown
        loginButton.textContent = data.nome;
        
        // Criar o menu dropdown
        const dropdown = document.createElement('div');
        dropdown.className = 'user-dropdown';
        dropdown.innerHTML = `
          <ul>
            <li><a href="#">Minha Conta</a></li>
            <li><a href="#">Favoritos</a></li>
            <li><a href="logout.php">Sair</a></li>
          </ul>
        `;
        
        // Adicionar o dropdown ao botão de login
        document.querySelector('.login-button').appendChild(dropdown);
        
        // Mostrar o dropdown quando passar o mouse sobre o botão
        document.querySelector('.login-button').addEventListener('mouseenter', function() {
          dropdown.style.display = 'block';
        });
        
        document.querySelector('.login-button').addEventListener('mouseleave', function() {
          dropdown.style.display = 'none';
        });
      }
    })
    .catch(error => console.error('Erro ao verificar login:', error));
});